
function main
% This script is a demonstration of how to get the frequency-varying 
% transfer fucntion from seismograms recorded by the KiK-net station 
% Author: Hao Zhang, HUST, Wuhan China
% Date Created: 4 October 2021
% E-mail: 674238265@qq.com
%--------------------------------------------------------------------------
% Input parameters:
%   station name
%   well-log borehole depth 
%   well-log travel time of the shear wave
%   f_step: step length of the moving frequency window 
%   f_bandwidth: width of the frequency window 
%--------------------------------------------------------------------------
% Abbreviation:
%   hf: transfer function in the frequency domain
%   tf: transfer function in the time domain
%   sbr: surface to borehole spectral ratio
%--------------------------------------------------------------------------
% It may cost about 10 seconds to get the final result.
[research_period,kikname]=xlsread('G:\dispersion������Ϣ\research_period.xlsx',4);
kikname={'FKSH01'};
f_bandwidth=0.5;
f_step=0.1;
borehole_depth=100;
t_inf=0.08;
path=[kikname{1,1},'1103111515'];
%%
[rs,rb,f]=text_read_S(path);
[hf,sbr,F]=detect_hf(rs,rb,f);
[tf,F_central,t]=dispersion_f_ave(nanmean(hf,2),f,f_bandwidth,f_step);

t_based_KK_relation=imag(hilbert(log(sbr)))./F./2./pi+t_inf; %confirm the dispersion by K-K relation
%%
[x_tf,v_tf]=meshgrid(F_central,t.^-1*borehole_depth);
[x_tf,t_tf]=meshgrid(F_central,t);
figure (1)
subplot (1,2,1)
pcolor(x_tf,t_tf,tf);shading flat;
colormap(jet);colorbar;
hold on
plot (F(F<40),t_based_KK_relation(F<40),'.k')
xlabel('Frequecny (Hz)')
ylabel('time lapse (s)')
ylim([0,1])
xlim([0,40])
subplot (1,2,2)
pcolor(x_tf,v_tf,tf);shading flat;
colormap(jet);colorbar;
xlabel('Frequecny (Hz)')
ylabel('phase velocity (m/s)')
ylim([0,2000])
xlim([0,40])
title([kikname])
figure (2)
plot (F(F<40),log(sbr(F<40)))
xlabel('Frequecny (Hz)')
ylabel('ln (SBR)')
end
%==========================================================================
function [rs,rb,f]=text_read_S(path)
ew1=textread([path,'.EW1'],'%f','headerlines',17);
ew2=textread([path,'.EW2'],'%f','headerlines',17);
ns1=textread([path,'.NS1'],'%f','headerlines',17);
ns2=textread([path,'.NS2'],'%f','headerlines',17);
f=textread([path,'.EW1'],'%*s%*s%n',1,'headerlines',10);
[kb1,kb2]=textread([path,'.EW1'],'%*s%*s%n%*6s%n',1,'headerlines',13);
[ks1,ks2]=textread([path,'.EW2'],'%*s%*s%n%*6s%n',1,'headerlines',13);
kb=kb1/kb2;
ks=ks1/ks2;
s=length(ew1);
rbew=(ew1-mean(ew1(s-f*20:s-f*10)))*kb;
rsew=(ew2-mean(ew2(s-f*20:s-f*10)))*ks;
rbns=(ns1-mean(ns1(s-f*20:s-f*10)))*kb;
rsns=(ns2-mean(ns2(s-f*20:s-f*10)))*ks;
th=(0:17)/18*pi;
rs=rsew*cos(th)+rsns*sin(th);
rb=rbew*cos(th)+rbns*sin(th);
end
%==========================================================================
function re_ymdms=lis(kikname,research_period)
path=['H:\EARTHQUAKEDATA\',kikname];
a=ls(path);
a(1:2,:)=[];
s=size(a,1)-2;
a=a(1:6:s,7:16);%��ȷ����
ymdms=mat2cell(a,zeros(size(a,1),1)+1,10);
for j=1:size(ymdms,1)
    temp=(y2s(ymdms{j,1})-y2s('1103111446'));
    date(j,1)=temp/3600/24;
end
date_I=date>research_period(1,1)&date<research_period(1,2);
re_ymdms=ymdms(date_I);
end
function s=y2s(time1)
time1=str2num(time1);
m=mod(time1,100);
h=(mod(time1,10000)-m)/100;
d=(mod(time1,10^6)-h*100-m)/10000; 
m2=(mod(time1,10^8)-d*10^4-h*100-m)/10^6;
y=fix(time1/10^8);
s=y*365*24*3600+m2*30*24*3600+m*60+h*3600+d*3600*24;
end 
%==========================================================================
function [hf,sbr,F]=detect_hf(rs,rb,f)
LB=0.1; HB=50;
b=size(rs);
s=length(rs);
F=(0:f/2^nextpow2(s):f-f/2^nextpow2(s))';
I1=F>LB&F<HB;
I2=F>f-HB&F<f-LB;
res_fft=fft(rs,2^nextpow2(b(1)));
reb_fft=fft(rb,2^nextpow2(b(1)));
hf=(res_fft)./reb_fft;
hf(~(I1|I2),:)=0;
hf=nanmean(hf,2);

w=parzenwin(ceil(length(res_fft)/f*0.5))./sum(parzenwin(ceil(length(res_fft)/f*0.5)));
sbr=imfilter(abs(res_fft),w,'symmetric','same')./imfilter(abs(reb_fft),w,'symmetric','same');
sbr(~(I1|I2),:)=1;
sbr=nanmean(sbr,2);

end
%==========================================================================
function [t_hf,F_central,t]=dispersion_f_ave(hf,f,f_bandwidth,f_step)
s=length(hf);
F=0:f/2^nextpow2(s):f-f/2^nextpow2(s);
b_1hz=sum(F>0&F<=1);
b=fix(f_bandwidth*b_1hz);
n=fix(f_step*b_1hz);
m=fix(2^nextpow2(s)/n/f*40);
for i=1:m-fix(b/n)-1
    temp_hf=hf;
    F_central(i,1)=f_step*(i-1)+f_bandwidth/2;
    LB=f_step*(i-1);
    HB=f_step*(i-1)+f_bandwidth;
    I1=F'>LB&F'<HB;
    I2=F'>f-HB&F'<f-LB;
    temp_hf(~(I1|I2),:)=0;
    df=real(ifft(temp_hf));
    df_0_1=df(1:f);
    t0=0:1/f:1-1/f;
    t=(0:0.001:1-0.001)';
    for j=1:size(df,2)
        df_re(:,j)=interp1(t0,df_0_1(:,j),t,'spline',0);
        df_re(:,j)=df_re(:,j)/max(abs(df_re(:,j)));
    end
    t_hf(:,i)=nanmean(df_re,2);
end
end

